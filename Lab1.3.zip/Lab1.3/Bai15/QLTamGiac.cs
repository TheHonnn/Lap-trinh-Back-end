﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class QuanLyTamGiac
{
    private List<TamGiac> danhSach = new List<TamGiac>();

    public void NhapDanhSach()
    {
        Console.Write("Nhập số lượng tam giác: ");
        int n = int.Parse(Console.ReadLine());
        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"--- Tam giác thứ {i + 1} ---");
            TamGiac tg = new TamGiac();
            tg.Nhap();
            danhSach.Add(tg);
        }
    }

    public void HienThiToanBoTamGiac()
    {
        Console.WriteLine("\n=== Danh sách tam giác và thông tin ===");
        foreach (var tg in danhSach)
        {
            tg.HienThi();
            Console.WriteLine("-----------------------------");
        }
    }

    public void HienThiTamGiacVuong()
    {
        Console.WriteLine("\n=== Các tam giác vuông ===");
        foreach (var tg in danhSach)
        {
            if (tg.LaTamGiacVuong())
            {
                tg.HienThi();
                Console.WriteLine("-----------------------------");
            }
        }
    }
}
