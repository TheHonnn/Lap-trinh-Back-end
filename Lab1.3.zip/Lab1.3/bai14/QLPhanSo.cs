﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class QLPhanSo
{
    public PhanSo A { get; set; }
    public PhanSo B { get; set; }

    public void Nhap()
    {
        Console.WriteLine("Nhập phân số A:");
        A = new PhanSo();
        A.Nhap();

        Console.WriteLine("Nhập phân số B:");
        B = new PhanSo();
        B.Nhap();
    }

    public void TinhToan(int luaChon)
    {
        PhanSo kq;
        switch (luaChon)
        {
            case 1:
                kq = A.Cong(B);
                Console.Write("Tổng A + B = ");
                kq.HienThi();
                break;
            case 2:
                kq = A.Tru(B);
                Console.Write("Hiệu A - B = ");
                kq.HienThi();
                break;
            case 3:
                kq = A.Nhan(B);
                Console.Write("Tích A * B = ");
                kq.HienThi();
                break;
            case 4:
                if (B.TuSo == 0)
                {
                    Console.WriteLine("Không thể chia cho phân số có tử số bằng 0.");
                    return;
                }
                kq = A.Chia(B);
                Console.Write("Thương A / B = ");
                kq.HienThi();
                break;
            default:
                Console.WriteLine("Lựa chọn không hợp lệ.");
                break;
        }
    }
}

