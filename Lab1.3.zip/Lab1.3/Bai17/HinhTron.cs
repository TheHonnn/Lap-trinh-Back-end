﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class HinhTron
{
    public Diem tam;
    public float banKinh;

    public HinhTron()
    {
        tam = new Diem();
    }

    public HinhTron(Diem d, float r)
    {
        tam = d;
        banKinh = r;
    }

    public void Nhap()
    {
        Console.WriteLine("Nhập tọa độ tâm:");
        tam.Nhap();
        Console.Write("Nhập bán kính: ");
        banKinh = float.Parse(Console.ReadLine());
    }

    public void Hien()
    {
        Console.Write("Tâm: ");
        tam.Hien();
        Console.WriteLine($", Bán kính: {banKinh}, Chu vi: {ChuVi():F2}, Diện tích: {DienTich():F2}");
    }

    public float ChuVi()
    {
        return 2 * (float)Math.PI * banKinh;
    }

    public float DienTich()
    {
        return (float)Math.PI * banKinh * banKinh;
    }

    public bool GiaoNhau(HinhTron khac)
    {
        float d = this.tam.TinhKhoangCach(khac.tam);
        return d < (this.banKinh + khac.banKinh);
    }
}
