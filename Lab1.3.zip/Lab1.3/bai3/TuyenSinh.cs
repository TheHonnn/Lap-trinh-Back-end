﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System;
using System.Collections.Generic;

class TuyenSinh
{
    private List<ThiSinh> danhSach = new List<ThiSinh>();

    public void NhapThiSinh()
    {
        Console.WriteLine("Chọn khối thi (A/B/C): ");
        string khoi = Console.ReadLine().ToUpper();
        ThiSinh ts = null;

        switch (khoi)
        {
            case "A": ts = new ThiSinhKhoiA(); break;
            case "B": ts = new ThiSinhKhoiB(); break;
            case "C": ts = new ThiSinhKhoiC(); break;
            default:
                Console.WriteLine("Khối không hợp lệ."); return;
        }

        ts.Nhap();
        danhSach.Add(ts);
    }

    public void HienThiThiSinhTrungTuyen()
    {
        Console.WriteLine("Danh sách thí sinh trúng tuyển:");
        foreach (var ts in danhSach)
        {
            double diemChuan = ts.KhoiThi switch
            {
                "A" => 15,
                "B" => 16,
                "C" => 13.5,
                _ => 0
            };

            if (ts.TinhTongDiem() >= diemChuan)
            {
                ts.HienThi();
            }
        }
    }

    public void TimTheoSoBaoDanh()
    {
        Console.Write("Nhập số báo danh cần tìm: ");
        string sbd = Console.ReadLine();

        foreach (var ts in danhSach)
        {
            if (ts.SoBaoDanh == sbd)
            {
                ts.HienThi();
                return;
            }
        }

        Console.WriteLine("Không tìm thấy thí sinh.");
    }

    public void HienThiTatCa()
    {
        Console.WriteLine("Danh sách tất cả thí sinh:");
        foreach (var ts in danhSach)
        {
            ts.HienThi();
        }
    }
}

