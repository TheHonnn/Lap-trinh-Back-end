﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;

public class HocSinh
{
    public string HoTen { get; set; }
    public int NamSinh { get; set; }
    public double TongDiem { get; set; }

    public void Nhap()
    {
        Console.Write("Nhập họ tên: ");
        HoTen = Console.ReadLine();

        Console.Write("Nhập năm sinh: ");
        NamSinh = int.Parse(Console.ReadLine());

        Console.Write("Nhập tổng điểm: ");
        TongDiem = double.Parse(Console.ReadLine());
    }

    public void Xuat()
    {
        Console.WriteLine($"{ChuanHoaTen(HoTen),-30} | {NamSinh,-10} | {TongDiem,-10}");
    }

    // Hàm chuẩn hóa chữ cái đầu viết hoa
    private string ChuanHoaTen(string hoTen)
    {
        TextInfo textInfo = new CultureInfo("vi-VN", false).TextInfo;
        return textInfo.ToTitleCase(hoTen.ToLower());
    }
}
