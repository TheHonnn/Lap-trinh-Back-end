﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class TheMuon
{
    public string SoPhieuMuon { get; set; }
    public DateTime NgayMuon { get; set; }
    public DateTime HanTra { get; set; }
    public string SoHieuSach { get; set; }
    public SinhVien SinhVien { get; set; } = new SinhVien();

    public void Nhap()
    {
        Console.Write("Nhập số phiếu mượn: ");
        SoPhieuMuon = Console.ReadLine();
        Console.Write("Nhập ngày mượn (dd/MM/yyyy): ");
        NgayMuon = DateTime.ParseExact(Console.ReadLine(), "dd/MM/yyyy", null);
        Console.Write("Nhập hạn trả (dd/MM/yyyy): ");
        HanTra = DateTime.ParseExact(Console.ReadLine(), "dd/MM/yyyy", null);
        Console.Write("Nhập số hiệu sách: ");
        SoHieuSach = Console.ReadLine();

        Console.WriteLine("=== Nhập thông tin sinh viên ===");
        SinhVien.Nhap();
    }

    public void HienThi()
    {
        Console.WriteLine($"\nSố phiếu mượn: {SoPhieuMuon}, Ngày mượn: {NgayMuon.ToString("dd/MM/yyyy")}, Hạn trả: {HanTra.ToString("dd/MM/yyyy")}, Số hiệu sách: {SoHieuSach}");
        SinhVien.HienThi();
    }
}

public class QuanLyMuonSach
{
    private List<TheMuon> danhSach = new List<TheMuon>();

    public void NhapDanhSach()
    {
        Console.Write("Nhập số lượng thẻ mượn: ");
        int n = int.Parse(Console.ReadLine());
        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"\n--- Nhập thẻ mượn thứ {i + 1} ---");
            TheMuon tm = new TheMuon();
            tm.Nhap();
            danhSach.Add(tm);
        }
    }

    public void HienThiDanhSach()
    {
        Console.WriteLine("\n=== DANH SÁCH THẺ MƯỢN ===");
        foreach (var tm in danhSach)
        {
            tm.HienThi();
        }
    }

    public void TimTheoMaSV(string ma)
    {
        Console.WriteLine($"\n--- Tìm thẻ mượn theo mã SV: {ma} ---");
        foreach (var tm in danhSach)
        {
            if (tm.SinhVien.MaSoSV.Equals(ma, StringComparison.OrdinalIgnoreCase))
            {
                tm.HienThi();
                return;
            }
        }
        Console.WriteLine("Không tìm thấy.");
    }

    public void HienThiDenHanTra()
    {
        Console.WriteLine("\n--- Danh sách sinh viên đến hạn trả sách ---");
        DateTime today = DateTime.Today;
        foreach (var tm in danhSach)
        {
            if (tm.HanTra <= today)
            {
                tm.HienThi();
            }
        }
    }
}
