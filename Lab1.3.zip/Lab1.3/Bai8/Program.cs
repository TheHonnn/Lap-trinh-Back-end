﻿using System;

class Program
{
    static void Main()
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        QuanLyMuonSach ql = new QuanLyMuonSach();

        int luaChon;
        do
        {
            Console.WriteLine("\n======= MENU =======");
            Console.WriteLine("1. Nhập danh sách thẻ mượn");
            Console.WriteLine("2. Hiển thị danh sách thẻ mượn");
            Console.WriteLine("3. Tìm kiếm theo mã sinh viên");
            Console.WriteLine("4. Hiển thị sinh viên đến hạn trả sách");
            Console.WriteLine("0. Thoát");
            Console.Write("Chọn: ");
            luaChon = int.Parse(Console.ReadLine());

            switch (luaChon)
            {
                case 1:
                    ql.NhapDanhSach();
                    break;
                case 2:
                    ql.HienThiDanhSach();
                    break;
                case 3:
                    Console.Write("Nhập mã sinh viên cần tìm: ");
                    string ma = Console.ReadLine();
                    ql.TimTheoMaSV(ma);
                    break;
                case 4:
                    ql.HienThiDenHanTra();
                    break;
                case 0:
                    Console.WriteLine("Thoát chương trình.");
                    break;
                default:
                    Console.WriteLine("Lựa chọn không hợp lệ.");
                    break;
            }

        } while (luaChon != 0);
    }
}
