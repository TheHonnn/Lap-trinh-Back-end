﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class KhachThue : Nguoi
{
    public int SoNgayTro { get; set; }
    public string LoaiPhong { get; set; }
    public double GiaPhong { get; set; }

    public override void Nhap()
    {
        base.Nhap();

        int soNgay;
        Console.Write("Nhập số ngày trọ: ");
        while (!int.TryParse(Console.ReadLine(), out soNgay))
        {
            Console.Write("Sai định dạng! Nhập lại số ngày trọ: ");
        }
        SoNgayTro = soNgay;

        Console.Write("Nhập loại phòng: ");
        LoaiPhong = Console.ReadLine();

        double gia;
        Console.Write("Nhập giá phòng/ngày: ");
        while (!double.TryParse(Console.ReadLine(), out gia))
        {
            Console.Write("Sai định dạng! Nhập lại giá phòng: ");
        }
        GiaPhong = gia;
    }

    public override void HienThi()
    {
        base.HienThi();
        Console.WriteLine($"Số ngày trọ: {SoNgayTro}, Loại phòng: {LoaiPhong}, Giá phòng/ngày: {GiaPhong}, Thành tiền: {TinhTien()}");
    }

    public double TinhTien()
    {
        return SoNgayTro * GiaPhong;
    }
}


