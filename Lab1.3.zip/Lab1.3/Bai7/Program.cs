﻿using System;

class Program
{
    static void Main()
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;

        QuanLyCBGV ql = new QuanLyCBGV();
        int chon;

        do
        {
            Console.WriteLine("\n--- MENU QUẢN LÝ CÁN BỘ GIÁO VIÊN ---");
            Console.WriteLine("1. Nhập danh sách cán bộ giáo viên");
            Console.WriteLine("2. Hiển thị tất cả cán bộ giáo viên");
            Console.WriteLine("3. Tìm kiếm theo quê quán");
            Console.WriteLine("4. Hiển thị cán bộ có lương thực lĩnh > 5 triệu");
            Console.WriteLine("0. Thoát");
            Console.Write("Chọn chức năng: ");
            chon = int.Parse(Console.ReadLine());

            switch (chon)
            {
                case 1:
                    ql.NhapDanhSach();
                    break;
                case 2:
                    ql.HienThiTatCa();
                    break;
                case 3:
                    Console.Write("Nhập quê quán cần tìm: ");
                    string que = Console.ReadLine();
                    ql.TimTheoQueQuan(que);
                    break;
                case 4:
                    ql.HienThiLuongTren5Trieu();
                    break;
                case 0:
                    Console.WriteLine("Thoát chương trình.");
                    break;
                default:
                    Console.WriteLine("Chọn sai! Mời chọn lại.");
                    break;
            }

        } while (chon != 0);
    }
}
