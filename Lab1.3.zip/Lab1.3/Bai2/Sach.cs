﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bai2;

public class Sach : TaiLieu
{
    public string TenTacGia { get; set; }
    public int SoTrang { get; set; }

    public override void Nhap()
    {
        base.Nhap();
        Console.Write("Nhập tên tác giả: ");
        TenTacGia = Console.ReadLine();
        Console.Write("Nhập số trang: ");
        SoTrang = int.Parse(Console.ReadLine());
    }

    public override void HienThi()
    {
        base.HienThi();
        Console.WriteLine($"Tác giả: {TenTacGia}, Số trang: {SoTrang}");
    }
}

public class TapChi : TaiLieu
{
    public int SoPhatHanh { get; set; }
    public int ThangPhatHanh { get; set; }

    public override void Nhap()
    {
        base.Nhap();
        Console.Write("Nhập số phát hành: ");
        SoPhatHanh = int.Parse(Console.ReadLine());
        Console.Write("Nhập tháng phát hành: ");
        ThangPhatHanh = int.Parse(Console.ReadLine());
    }

    public override void HienThi()
    {
        base.HienThi();
        Console.WriteLine($"Số phát hành: {SoPhatHanh}, Tháng phát hành: {ThangPhatHanh}");
    }
}

public class Bao : TaiLieu
{
    public DateTime NgayPhatHanh { get; set; }

    public override void Nhap()
    {
        base.Nhap();
        Console.Write("Nhập ngày phát hành (dd/MM/yyyy): ");
        NgayPhatHanh = DateTime.Parse(Console.ReadLine());
    }

    public override void HienThi()
    {
        base.HienThi();
        Console.WriteLine($"Ngày phát hành: {NgayPhatHanh:dd/MM/yyyy}");
    }
}
