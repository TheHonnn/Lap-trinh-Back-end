﻿using Microsoft.AspNetCore.Mvc;
using LAB2.Models;
using System.Collections.Generic;
using System.Linq;

namespace LAB2.Controllers
{
    public class TodoController : Controller
    {
        private static List<Todo> todoList = new List<Todo>
        {
            new Todo { Id = 1, Task = "Ôn tập HTML" },
            new Todo { Id = 2, Task = "Ôn tập CSS" },
            new Todo { Id = 3, Task = "Ôn tập Bootstrap" }
        };

        public IActionResult Index()
        {
            return View(todoList);
        }

        // GET: Add
        public IActionResult Add()
        {
            return View();
        }

        // POST: Add
        [HttpPost]
        public IActionResult Add(Todo model)
        {
            if (ModelState.IsValid)
            {
                model.Id = todoList.Any() ? todoList.Max(x => x.Id) + 1 : 1;
                todoList.Add(model);
                return RedirectToAction("Index");
            }
            return View(model);
        }

        // GET: Edit
        public IActionResult Edit(int id)
        {
            var item = todoList.FirstOrDefault(x => x.Id == id);
            if (item == null) return NotFound();
            return View(item);
        }

        // POST: Edit
        [HttpPost]
        public IActionResult Edit(Todo model)
        {
            if (ModelState.IsValid)
            {
                var item = todoList.FirstOrDefault(x => x.Id == model.Id);
                if (item == null) return NotFound();
                item.Task = model.Task;
                return RedirectToAction("Index");
            }
            return View(model);
        }

        // GET: Delete
        public IActionResult Delete(int id)
        {
            var item = todoList.FirstOrDefault(x => x.Id == id);
            if (item == null) return NotFound();
            todoList.Remove(item);
            return RedirectToAction("Index");
        }
    }
}
