﻿using System.ComponentModel.DataAnnotations;

namespace LAB2.Models
{
    public class Todo
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Vui lòng nhập nội dung công việc")]
        public string Task { get; set; }
    }
}
